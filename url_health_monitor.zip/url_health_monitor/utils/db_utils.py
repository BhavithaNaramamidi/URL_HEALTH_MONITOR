import sqlite3
import pandas as pd

DB_FILE = "url_health.db"

def init_db():
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS url_checks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT NOT NULL,
                status TEXT NOT NULL,
                response_time REAL,
                checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()

def insert_check(url, status, response_time):
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute(
            "INSERT INTO url_checks (url, status, response_time) VALUES (?, ?, ?)",
            (url, status, response_time)
        )
        conn.commit()

def get_history():
    with sqlite3.connect(DB_FILE) as conn:
        return pd.read_sql_query("SELECT * FROM url_checks ORDER BY checked_at DESC", conn)

def get_uptime_stats(url=None):
    with sqlite3.connect(DB_FILE) as conn:
        c = conn.cursor()
        if url:
            c.execute("""
                SELECT COUNT(*) as total,
                       SUM(CASE WHEN status='UP' THEN 1 ELSE 0 END) as up
                FROM url_checks WHERE url=?
            """, (url,))
            return c.fetchone()
        else:
            c.execute("""
                SELECT url,
                       COUNT(*) as total,
                       SUM(CASE WHEN status='UP' THEN 1 ELSE 0 END) as up
                FROM url_checks GROUP BY url
            """)
            return c.fetchall()

def clear_history():
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("DELETE FROM url_checks")
        conn.commit()
