# import streamlit as st
# import requests
# import time
# import pandas as pd
# from utils.db_utils import save_to_db, get_conn_cursor, get_metrics, plot_history

# # Get DB connection and cursor
# conn, c = get_conn_cursor()

# st.set_page_config(page_title="URL Health Monitor", layout="wide")
# st.title("🌐 URL Health Monitor")
# st.write("Enter URLs below (one per line) to check if they are UP or DOWN.")

# # Input URLs
# urls_input = st.text_area("Enter URLs (one per line)", height=150)

# # Buttons in two columns
# col1, col2 = st.columns(2)
# with col1:
#     check_clicked = st.button("✅ Check URLs")
# with col2:
#     history_clicked = st.button("🔍 View History")

# def check_url(url):
#     if not url.startswith("http"):
#         url = "http://" + url
#     try:
#         start = time.time()
#         response = requests.get(url, timeout=5)
#         end = time.time()
#         response_time = round(end - start, 2)
#         status = "UP" if response.status_code < 400 else "DOWN"
#     except Exception:
#         status = "DOWN"
#         response_time = None
#     return status, response_time

# if check_clicked:
#     urls = [u.strip() for u in urls_input.split("\n") if u.strip()]
#     if urls:
#         for url in urls:
#             st.markdown("---")
#             st.subheader(f"🔗 {url}")
#             status, resp_time = check_url(url)
#             save_to_db(url, status, resp_time)

#             st.write(f"Status: {'🟢 UP' if status == 'UP' else '🔴 DOWN'}")
#             st.write(f"Response Time: {resp_time if resp_time is not None else 'N/A'} seconds")

#             metrics = get_metrics(url)
#             st.markdown("#### 📊 Metrics")
#             c1, c2, c3 = st.columns(3)
#             c1.metric("Total Checks", metrics['total_checks'])
#             c2.metric("Uptime %", f"{metrics['uptime_percent']}%")
#             c3.metric("Avg Response Time", f"{metrics['avg_response_time']} s")

#             with st.expander("📈 Uptime History Chart"):
#                 plot_history(metrics['df'])
#     else:
#         st.warning("Please enter at least one URL.")

# if history_clicked:
#     st.markdown("---")
#     st.subheader("📜 Full URL Check History")
#     df_history = pd.read_sql_query("SELECT * FROM url_status ORDER BY timestamp DESC", conn)
#     if df_history.empty:
#         st.info("No check history available.")
#     else:
#         st.dataframe(df_history, use_container_width=True)
import streamlit as st
import requests
import time
import pandas as pd
from utils.db_utils import init_db, insert_check, get_history, get_uptime_stats

# Initialize database
init_db()

def check_url(url):
    if not url.startswith("http://") and not url.startswith("https://"):
        url = "https://" + url
    try:
        start_time = time.time()
        response = requests.get(url, timeout=5)
        response_time = round((time.time() - start_time) * 1000, 2)
        status = "UP" if response.status_code == 200 else "DOWN"
    except Exception:
        response_time = None
        status = "DOWN"
    insert_check(url, status, response_time)
    return status, response_time

# Streamlit UI
st.set_page_config(page_title="URL Health Monitor", layout="centered")
st.title("🔍 URL Health Monitor")

url_input = st.text_area("Enter one or more URLs (one per line):")
if st.button("Check URLs"):
    urls = url_input.strip().split("\n")
    results = []
    for url in urls:
        url = url.strip()
        if url:
            status, response_time = check_url(url)
            results.append({"URL": url, "Status": status, "Response Time (ms)": response_time or "N/A"})
    st.success("Check complete!")
    st.dataframe(pd.DataFrame(results))

if st.button("View History"):
    history = get_history()
    if history:
        df = pd.DataFrame(history, columns=["URL", "Status", "Response Time (ms)", "Checked At"])
        st.subheader("🕒 URL Check History")
        st.dataframe(df)
    else:
        st.info("No history found.")

if st.button("Uptime Metrics"):
    stats = get_uptime_stats()
    if stats:
        metric_data = []
        for url, total, up in stats:
            uptime_percent = round((up / total) * 100, 2) if total > 0 else 0
            metric_data.append({"URL": url, "Uptime %": uptime_percent})
        st.subheader("📊 Uptime Metrics")
        st.dataframe(pd.DataFrame(metric_data))
    else:
        st.info("No stats to display.")
