import streamlit as st
import requests
import time
import pandas as pd
import sqlite3
from urllib.parse import urlparse
from llm_utils import summarize_results_locally

DB_FILE = "url_health.db"

# --- DB Helpers ---
def init_db():
    with sqlite3.connect(DB_FILE) as conn:
        c = conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS url_checks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT NOT NULL,
                status TEXT NOT NULL,
                response_time REAL,
                checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()

def insert_check(url, status, response_time):
    with sqlite3.connect(DB_FILE) as conn:
        c = conn.cursor()
        c.execute("INSERT INTO url_checks (url, status, response_time) VALUES (?, ?, ?)",
                  (url, status, response_time))
        conn.commit()

def get_history():
    with sqlite3.connect(DB_FILE) as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM url_checks ORDER BY checked_at DESC")
        return c.fetchall()

def get_uptime_stats(url=None):
    with sqlite3.connect(DB_FILE) as conn:
        c = conn.cursor()
        if url:
            c.execute("""
                SELECT COUNT(*), SUM(CASE WHEN status='UP' THEN 1 ELSE 0 END)
                FROM url_checks WHERE url=?
            """, (url,))
            return c.fetchone()
        else:
            c.execute("""
                SELECT url, COUNT(*), SUM(CASE WHEN status='UP' THEN 1 ELSE 0 END)
                FROM url_checks GROUP BY url
            """)
            return c.fetchall()

def clear_history():
    with sqlite3.connect(DB_FILE) as conn:
        c = conn.cursor()
        c.execute("DELETE FROM url_checks")
        conn.commit()

# --- URL Check ---
def normalize_url(url):
    parsed = urlparse(url)
    if not parsed.scheme:
        url = "https://" + url  # default to HTTPS
    return url

def check_url(url):
    url = normalize_url(url)
    try:
        headers = {"User-Agent": "Mozilla/5.0"}
        start_time = time.time()
        response = requests.get(url, headers=headers, timeout=5, allow_redirects=True)
        response_time = round((time.time() - start_time) * 1000, 2)
        status = "UP" if response.ok else "DOWN"
    except Exception as e:
        print(f"Error checking {url}: {e}")
        response_time = None
        status = "DOWN"
    insert_check(url, status, response_time)
    return status, response_time

# --- Main App ---
st.set_page_config(page_title="URL Health Monitor", layout="wide")
st.title("🌐 URL Health Monitor (Local LLM Powered)")

init_db()

url_input = st.text_area("Enter URLs (one per line):")

col1, col2 = st.columns([1, 1])

with col1:
    if st.button("✅ Check URLs"):
        urls = [u.strip() for u in url_input.split("\n") if u.strip()]
        if not urls:
            st.warning("Please enter at least one URL.")
        else:
            results = []
            for url in urls:
                status, resp_time = check_url(url)
                results.append({
                    "URL": url,
                    "Status": status,
                    "Response Time (ms)": resp_time if resp_time is not None else "N/A"
                })

            st.subheader("✅ Check Results")
            df_results = pd.DataFrame(results)
            st.dataframe(df_results)

            # Show uptime metrics per URL
            st.subheader("📊 Uptime Metrics")
            uptime_data = []
            for url in urls:
                total, up = get_uptime_stats(url)
                uptime_pct = round((up / total) * 100, 2) if total else 0
                uptime_data.append({"URL": url, "Uptime %": uptime_pct})
            st.dataframe(pd.DataFrame(uptime_data))

            # LLM summary
            with st.expander("🧠 LLM Summary of Results"):
                summary_text = summarize_results_locally(results)
                st.markdown(summary_text)

with col2:
    if st.button("🗑️ Clear History"):
        clear_history()
        st.success("History cleared.")

st.markdown("---")
with st.expander("📂 View History"):
    history = get_history()
    if history:
        df_hist = pd.DataFrame(history, columns=["ID", "URL", "Status", "Response Time (ms)", "Checked At"])
        st.dataframe(df_hist.drop(columns=["ID"]))
    else:
        st.info("No history available yet.")
