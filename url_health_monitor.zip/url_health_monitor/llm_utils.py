import requests

def summarize_results_locally(data):
    prompt = "You are an assistant that summarizes URL health check results.\n\n"
    prompt += "Here are the recent results:\n"
    for row in data:
        prompt += f"- {row['URL']}: {row['Status']} (Response Time: {row['Response Time (ms)']} ms)\n"
    prompt += "\nGive a short summary of the overall health."

    try:
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": "tinyllama", "prompt": prompt, "stream": False}
        )
        if response.ok:
            return response.json()["response"].strip()
        else:
            return "Error calling local LLM: " + response.text
    except Exception as e:
        return f"⚠️ Could not connect to local LLM (Ollama). Error: {e}"
